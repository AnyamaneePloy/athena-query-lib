# Athena Query Library

A Python library for querying AWS Athena and processing results as pandas DataFrames.

## Installation

```bash
pip install athena-query-lib
